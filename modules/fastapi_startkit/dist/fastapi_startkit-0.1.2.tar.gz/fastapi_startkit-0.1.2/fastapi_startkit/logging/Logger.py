class Logger:
    pass